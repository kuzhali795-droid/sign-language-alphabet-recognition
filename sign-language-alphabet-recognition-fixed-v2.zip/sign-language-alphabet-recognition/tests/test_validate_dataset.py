import tempfile
import unittest
from pathlib import Path
from validate_dataset import class_image_counts, validate_training_dataset


class DatasetValidationTests(unittest.TestCase):
    def test_counts_supported_images_case_insensitively(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "A").mkdir()
            (root / "A" / "one.JPG").write_bytes(b"not decoded by validator")
            (root / "A" / "notes.txt").write_text("ignore")
            self.assertEqual(class_image_counts(root), {"A": 1})

    def test_training_requires_two_classes(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for label in ("A", "B"):
                (root / label).mkdir()
                for i in range(2):
                    (root / label / f"{i}.jpg").write_bytes(b"x")
            self.assertEqual(validate_training_dataset(root), {"A": 2, "B": 2})

    def test_training_rejects_insufficient_class(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for label in ("A", "B"):
                (root / label).mkdir()
                (root / label / "one.jpg").write_bytes(b"x")
            with self.assertRaisesRegex(ValueError, "at least 2"):
                validate_training_dataset(root)


if __name__ == "__main__":
    unittest.main()
