# Accessibility, Responsible Use, and Limitations

This is a student prototype for recognizing a limited set of static alphabet gestures. It is not a complete sign-language translation system.

- A sign language is a full language; alphabet handshapes alone do not represent its grammar or everyday conversation.
- Some signs require motion, two hands, facial expression, or context and cannot be represented by a single still image.
- Similar handshapes may be confused. Inspect the per-class precision, recall, F1-score, and confusion matrix.
- The dataset may not represent all signers, skin tones, ages, hand sizes, lighting, backgrounds, camera angles, or disabilities.
- A high model score is not necessarily a calibrated probability or proof of correctness. The demo displays an uncertainty message below a chosen threshold, but that threshold is only a simple heuristic.
- Consult credible sign-language community resources and, where possible, Deaf signers or accessibility specialists before describing real-world usefulness.
- Do not use this prototype for emergency, medical, legal, or other high-stakes communication.
- Respect dataset licenses, privacy, consent, attribution, and redistribution rules.
- Future work: signer-separated evaluation, larger and more diverse data, hand-landmark baseline comparison, calibration, temporal models for motion-based signs, and user testing with community guidance.
