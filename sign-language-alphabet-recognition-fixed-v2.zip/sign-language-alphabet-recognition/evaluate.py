"""Evaluate on a separate labelled test dataset and save a confusion matrix."""
from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay

ROOT = Path(__file__).resolve().parent
TEST_DIR = ROOT / "dataset" / "test"
MODEL_PATH = ROOT / "models" / "sign_language_model.keras"
LABELS_PATH = ROOT / "models" / "class_names.json"
IMAGE_SIZE = (128, 128)
BATCH_SIZE = 32

def main():
    if not TEST_DIR.exists() or not any(p.is_dir() for p in TEST_DIR.iterdir()):
        raise FileNotFoundError(
            "Create dataset/test/<LETTER>/ folders with held-out test images first."
        )
    if not MODEL_PATH.exists() or not LABELS_PATH.exists():
        raise FileNotFoundError("Train the model first: python train.py")

    labels = json.loads(LABELS_PATH.read_text(encoding="utf-8"))
    ds = keras.utils.image_dataset_from_directory(
        TEST_DIR, image_size=IMAGE_SIZE, batch_size=BATCH_SIZE,
        shuffle=False, label_mode="int"
    )
    if ds.class_names != labels:
        raise ValueError(
            f"Test classes {ds.class_names} do not match training classes {labels}. "
            "Ensure each split has the same class folders."
        )

    if len(labels) < 2:
        raise ValueError("The saved class_names.json must contain at least two classes.")
    model = keras.models.load_model(MODEL_PATH)
    if len(labels) != int(model.output_shape[-1]):
        raise ValueError("Label count does not match model outputs. Retrain the model or restore the matching class_names.json.")
    y_true = np.concatenate([y.numpy() for _, y in ds])
    probabilities = model.predict(ds, verbose=1)
    y_pred = np.argmax(probabilities, axis=1)

    print("\nPer-class evaluation:")
    print(classification_report(y_true, y_pred, target_names=labels, zero_division=0))
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(labels))))
    Path(ROOT / "reports").mkdir(exist_ok=True)
    display = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    display.plot(xticks_rotation=45, cmap="Blues", values_format="d")
    plt.title("Static Sign Alphabet Recognition - Confusion Matrix")
    plt.tight_layout()
    output = ROOT / "reports" / "confusion_matrix.png"
    plt.savefig(output, dpi=160)
    print(f"Confusion matrix saved to: {output}")

if __name__ == "__main__":
    main()
