"""Live webcam demo. Press q to quit."""
from pathlib import Path
import json
import cv2
import numpy as np
from tensorflow import keras

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "sign_language_model.keras"
LABELS_PATH = ROOT / "models" / "class_names.json"
IMAGE_SIZE = (128, 128)
CONFIDENCE_THRESHOLD = 0.60

def main():
    if not MODEL_PATH.exists() or not LABELS_PATH.exists():
        raise FileNotFoundError("Train the model first: python train.py")
    model = keras.models.load_model(MODEL_PATH)
    labels = json.loads(LABELS_PATH.read_text(encoding="utf-8"))
    if len(labels) != int(model.output_shape[-1]):
        raise ValueError("Label count does not match model outputs. Retrain the model or restore the matching class_names.json.")
    camera = cv2.VideoCapture(0)
    if not camera.isOpened():
        raise RuntimeError("Could not open webcam. Check camera permissions or device index.")

    print("Webcam started. Press q in the video window to quit.")
    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                print("Could not read a frame from the webcam.")
                break

            # The model expects RGB images. The frame is mirrored for a natural selfie view.
            frame = cv2.flip(frame, 1)
            height, width = frame.shape[:2]
            x1, y1 = int(width * 0.25), int(height * 0.15)
            x2, y2 = int(width * 0.75), int(height * 0.85)
            roi = frame[y1:y2, x1:x2]
            rgb = cv2.cvtColor(roi, cv2.COLOR_BGR2RGB)
            resized = cv2.resize(rgb, IMAGE_SIZE)
            probs = model.predict(np.expand_dims(resized, axis=0), verbose=0)[0]
            idx = int(np.argmax(probs))
            score = float(probs[idx])

            if score >= CONFIDENCE_THRESHOLD:
                text = f"{labels[idx]}  score: {score:.1%}"
            else:
                text = f"Uncertain  top: {labels[idx]} ({score:.1%})"
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, text, (20, 40), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, (0, 255, 0), 2, cv2.LINE_AA)
            cv2.imshow("Static Sign Alphabet Recognition - press q to quit", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        camera.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
