"""
Train a static sign-language alphabet image classifier.

Expected dataset layout:
dataset/
  train/
    A/ image1.jpg image2.jpg ...
    B/ ...
    C/ ...
    ...
  test/  (optional; used by evaluate.py, not by this script)

Use only a dataset whose license permits your intended use. The model learns
the classes present in dataset/train; it does not automatically support all
letters of every sign language.
"""
from pathlib import Path
import json
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from validate_dataset import validate_training_dataset

ROOT = Path(__file__).resolve().parent
TRAIN_DIR = ROOT / "dataset" / "train"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "sign_language_model.keras"
LABELS_PATH = MODEL_DIR / "class_names.json"

IMAGE_SIZE = (128, 128)
BATCH_SIZE = 32
SEED = 42
EPOCHS = 12

def main():
    if not TRAIN_DIR.exists():
        raise FileNotFoundError(
            f"Missing {TRAIN_DIR}. Create dataset/train/<LETTER>/ folders and add images."
        )

    try:
        counts = validate_training_dataset(TRAIN_DIR)
    except (FileNotFoundError, ValueError) as exc:
        raise SystemExit(f"Dataset validation failed: {exc}") from exc
    print("Training image counts:", counts)

    train_ds = keras.utils.image_dataset_from_directory(
        TRAIN_DIR,
        validation_split=0.2,
        subset="training",
        seed=SEED,
        image_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        label_mode="int",
    )
    val_ds = keras.utils.image_dataset_from_directory(
        TRAIN_DIR,
        validation_split=0.2,
        subset="validation",
        seed=SEED,
        image_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        label_mode="int",
    )

    class_names = train_ds.class_names
    if len(class_names) < 2:
        raise ValueError("Add images for at least two gesture classes.")
    print("Classes:", class_names)

    autotune = tf.data.AUTOTUNE
    train_ds = train_ds.cache().shuffle(1000, seed=SEED).prefetch(autotune)
    val_ds = val_ds.cache().prefetch(autotune)

    augmentation = keras.Sequential([
        layers.RandomRotation(0.04),
        layers.RandomZoom(0.08),
        layers.RandomTranslation(0.05, 0.05),
    ], name="safe_augmentation")

    inputs = keras.Input(shape=(*IMAGE_SIZE, 3))
    x = augmentation(inputs)
    x = layers.Rescaling(1.0 / 255)(x)
    x = layers.Conv2D(32, 3, padding="same", activation="relu")(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(64, 3, padding="same", activation="relu")(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(128, 3, padding="same", activation="relu")(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Dropout(0.25)(x)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.30)(x)
    outputs = layers.Dense(len(class_names), activation="softmax")(x)
    model = keras.Model(inputs, outputs)

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=3, restore_best_weights=True
        ),
        keras.callbacks.ModelCheckpoint(
            MODEL_PATH, monitor="val_loss", save_best_only=True
        ),
    ]

    model.summary()
    history = model.fit(
        train_ds, validation_data=val_ds, epochs=EPOCHS, callbacks=callbacks
    )
    model.save(MODEL_PATH)
    LABELS_PATH.write_text(json.dumps(class_names, indent=2), encoding="utf-8")
    print(f"\nModel saved to: {MODEL_PATH}")
    print(f"Class labels saved to: {LABELS_PATH}")
    best_val_accuracy = max(history.history.get("val_accuracy", [0.0]))
    print(f"Best validation accuracy: {best_val_accuracy:.4f}")
    print("This is validation performance, not a guarantee of real-world accuracy.")

if __name__ == "__main__":
    main()
