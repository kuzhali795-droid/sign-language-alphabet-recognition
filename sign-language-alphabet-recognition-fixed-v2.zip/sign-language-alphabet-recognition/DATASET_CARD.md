# Dataset Card — Basic Sign Language Alphabet Recognition

Complete this document with facts from the dataset you actually select.

- **Dataset name:** TODO
- **Original URL:** TODO
- **Creator / organization:** TODO
- **License and redistribution conditions:** TODO
- **Sign language and alphabet variant:** TODO
- **Intended use:** Educational research prototype for static alphabet gesture classification.
- **Excluded classes / ambiguous signs:** TODO
- **Class counts:** TODO (record each class, not only the total)
- **Image conditions:** TODO (lighting, backgrounds, camera angle, image dimensions)
- **Signer diversity:** TODO if documented by the dataset provider
- **Train/validation/test strategy:** 80/20 validation split inside `dataset/train`; separate `dataset/test` for final evaluation. Prefer signer-separated splits where signer IDs are available.
- **Privacy and consent:** Follow the dataset provider's terms. Do not identify signers or infer sensitive attributes.
- **Known limitations:** Static image classification does not translate signed-language grammar or conversation. Results may vary across signers, backgrounds, lighting, camera angles, and devices.
- **Citation / attribution:** TODO
