"""Validate the folder-based image dataset before training or evaluation."""
from pathlib import Path
import argparse

ROOT = Path(__file__).resolve().parent
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def class_image_counts(split_dir: Path) -> dict[str, int]:
    """Return supported image counts for each immediate class directory."""
    if not split_dir.is_dir():
        raise FileNotFoundError(f"Dataset split folder does not exist: {split_dir}")
    classes = sorted(p for p in split_dir.iterdir() if p.is_dir())
    if not classes:
        raise ValueError(
            f"No class folders found in {split_dir}. Create one folder per letter/gesture."
        )
    return {
        folder.name: sum(
            1 for item in folder.rglob("*")
            if item.is_file() and item.suffix.lower() in IMAGE_EXTENSIONS
        )
        for folder in classes
    }


def validate_training_dataset(split_dir: Path) -> dict[str, int]:
    counts = class_image_counts(split_dir)
    empty = [name for name, count in counts.items() if count < 2]
    if empty:
        raise ValueError(
            "Each training class needs at least 2 supported images for the 80/20 "
            f"training/validation split. Missing/insufficient classes: {', '.join(empty)}"
        )
    if len(counts) < 2:
        raise ValueError("Add images for at least two gesture classes.")
    return counts


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split", choices=("train", "test", "both"), default="both")
    args = parser.parse_args()
    splits = ("train", "test") if args.split == "both" else (args.split,)
    failed = False
    for split in splits:
        path = ROOT / "dataset" / split
        try:
            counts = class_image_counts(path)
            if split == "train":
                validate_training_dataset(path)
            print(f"\n{split}: {path}")
            for label, count in counts.items():
                print(f"  {label}: {count} image(s)")
            if not any(counts.values()):
                print("  WARNING: no supported images found")
                failed = True
        except (FileNotFoundError, ValueError) as exc:
            print(f"\nERROR ({split}): {exc}")
            failed = True
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
