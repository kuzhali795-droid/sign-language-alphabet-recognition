"""Predict the gesture class in a single image."""
from pathlib import Path
import json
import sys
import cv2
import numpy as np
from tensorflow import keras

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "sign_language_model.keras"
LABELS_PATH = ROOT / "models" / "class_names.json"
IMAGE_SIZE = (128, 128)
CONFIDENCE_THRESHOLD = 0.60

def main():
    if len(sys.argv) != 2:
        print('Usage: python predict_image.py "path/to/hand_image.jpg"')
        raise SystemExit(2)
    image_path = Path(sys.argv[1])
    if not MODEL_PATH.exists() or not LABELS_PATH.exists():
        raise FileNotFoundError("Train the model first: python train.py")
    image = cv2.imread(str(image_path))
    if image is None:
        raise FileNotFoundError(f"Could not read image: {image_path}")

    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    resized = cv2.resize(rgb, IMAGE_SIZE)
    model = keras.models.load_model(MODEL_PATH)
    labels = json.loads(LABELS_PATH.read_text(encoding="utf-8"))
    if len(labels) != int(model.output_shape[-1]):
        raise ValueError("Label count does not match model outputs. Retrain the model or restore the matching class_names.json.")
    probabilities = model.predict(np.expand_dims(resized, axis=0), verbose=0)[0]
    index = int(np.argmax(probabilities))
    confidence = float(probabilities[index])

    if confidence < CONFIDENCE_THRESHOLD:
        print(f"Uncertain prediction (top class {labels[index]}, score {confidence:.1%}).")
    else:
        print(f"Predicted letter: {labels[index]}")
        print(f"Model score: {confidence:.1%}")
    print("Note: the score is not a calibrated probability of being correct.")

if __name__ == "__main__":
    main()
